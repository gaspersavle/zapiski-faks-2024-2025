# GENERATED VERSION FILE
# TIME: Mon Jun 10 09:19:36 2024

__version__ = '0.5.0+93d7599'
short_version = '0.5.0'
