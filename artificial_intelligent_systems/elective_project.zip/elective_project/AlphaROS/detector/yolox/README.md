# An implementation of PyTorch version YOLOX

Forked and modified from https://github.com/Megvii-BaseDetection/YOLOX
